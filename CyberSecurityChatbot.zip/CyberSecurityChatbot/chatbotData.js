const chatbotData = {

"hi":`

<h2>👋 Welcome!</h2>

<p>Welcome to <b>Cyber Security Awareness Bot</b>.</p>

<p>Select any topic:</p>

<ul>
<li>🔐 Password</li>
<li>🎣 Phishing</li>
<li>🦠 Malware</li>
<li>🧬 Virus</li>
<li>🕵 Spyware</li>
<li>📱 OTP Fraud</li>
</ul>

<p>Type the topic name.</p>

`,

"password":`

<h2>🔐 Password Security</h2>

<p>A strong password protects your online accounts.</p>

<b>Strong Password Example</b>

<ul>
<li>Abhay@2026#</li>
<li>Janvi@123#</li>
</ul>

<b>Weak Password</b>

<ul>
<li>123456</li>
<li>password</li>
<li>abcdef</li>
</ul>

<b>Tips</b>

<ul>
<li>Use 12+ characters.</li>
<li>Mix letters, numbers and symbols.</li>
<li>Enable 2FA.</li>
</ul>

`,

"phishing":`

<h2>🎣 Phishing</h2>

<p>Phishing is a cyber attack where fake emails or websites steal your information.</p>

<b>Example</b>

<ul>
<li>Fake Bank Email</li>
<li>Fake Login Page</li>
</ul>

<b>Protection</b>

<ul>
<li>Don't click unknown links.</li>
<li>Check website URL.</li>
<li>Never share passwords.</li>
</ul>

`,

"malware":`

<h2>🦠 Malware</h2>

<p>Malware is harmful software that damages your computer.</p>

<b>Types</b>

<ul>
<li>Virus</li>
<li>Trojan</li>
<li>Spyware</li>
<li>Ransomware</li>
</ul>

<b>Protection</b>

<ul>
<li>Install Antivirus.</li>
<li>Keep Windows Updated.</li>
<li>Avoid Unknown Downloads.</li>
</ul>

`,

"virus":`

<h2>🧬 Computer Virus</h2>

<p>A virus spreads from one file to another and damages your system.</p>

<b>Prevention</b>

<ul>
<li>Use Antivirus.</li>
<li>Don't use infected USB drives.</li>
<li>Keep software updated.</li>
</ul>

`,

"spyware":`

<h2>🕵 Spyware</h2>

<p>Spyware secretly monitors your activities and steals information.</p>

<b>Protection</b>

<ul>
<li>Install trusted antivirus.</li>
<li>Avoid suspicious apps.</li>
<li>Keep your OS updated.</li>
</ul>

`,

"otp fraud":`

<h2>📱 OTP Fraud</h2>

<p>OTP Fraud happens when scammers trick you into sharing your OTP.</p>

<b>Remember</b>

<ul>
<li>Never share OTP.</li>
<li>Bank never asks OTP.</li>
<li>Don't trust unknown callers.</li>
</ul>

`

};