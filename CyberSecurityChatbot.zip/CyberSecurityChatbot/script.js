const chatbox = document.getElementById("chatbox");
const userInput = document.getElementById("userInput");

function addUserMessage(message) {
    chatbox.innerHTML += `
        <div class="user-message">
            <strong>👤 You</strong><br><br>
            ${message}
        </div>
    `;
    scrollChat();
}

function addBotMessage(message) {
    chatbox.innerHTML += `
        <div class="bot-message">
            <strong>🤖 Bot</strong><br><br>
            ${message}
        </div>
    `;
    scrollChat();
}

function showTyping(callback) {

    chatbox.innerHTML += `
        <div class="typing" id="typing">
            🤖 Bot is typing...
        </div>
    `;

    scrollChat();

    setTimeout(() => {

        const typing = document.getElementById("typing");

        if (typing) {
            typing.remove();
        }

        callback();

    }, 1000);
}

function sendMessage() {

    let message = userInput.value.trim();

    if (message === "") return;

    addUserMessage(message);

    userInput.value = "";

    let key = message.toLowerCase();

    showTyping(() => {

        if (chatbotData[key]) {
            addBotMessage(chatbotData[key]);
        }
        else {

            addBotMessage(`
            <h3>❌ Topic Not Found</h3>

            <p>Please choose one of the following topics:</p>

            <ul>
                <li>Password</li>
                <li>Phishing</li>
                <li>Malware</li>
                <li>Virus</li>
                <li>Spyware</li>
                <li>OTP Fraud</li>
            </ul>
            `);

        }

    });

}

function handleKey(event) {

    if (event.key === "Enter") {
        sendMessage();
    }

}

function scrollChat() {
    chatbox.scrollTop = chatbox.scrollHeight;
}